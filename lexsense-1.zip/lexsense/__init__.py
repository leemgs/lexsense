# LexSense package initializer
